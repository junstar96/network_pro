#pragma once

#define B_SIZE 30
#define PLAYERMAX 4
#define GHOSTMAX 10

