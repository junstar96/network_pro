#pragma once

void err_quit(char *msg);
void err_display(char *msg);