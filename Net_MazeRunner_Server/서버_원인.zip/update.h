#pragma once


void UpdateShaderResources();

