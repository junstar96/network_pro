#pragma once


//void collision(point a, int i, int j);
//void collision_sideline(point a, int i, int j);
//void collision_item(point a);
//void collision_endline(point a);
//void collision_ghost(float pos_x, float pos_z);
//bool collision_track(point a);