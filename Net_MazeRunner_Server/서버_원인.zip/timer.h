#pragma once

void TimerFunction(int value);